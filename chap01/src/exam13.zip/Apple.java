package exam13;

public class Apple {
	@Override
	public String toString() {
		return "I am Apple!";
	}

}
