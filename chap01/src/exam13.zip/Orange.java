package exam13;

public class Orange {
	@Override
	public String toString() {
		return "I am Orange!";
	}
}
