package exam13;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		
		map.put("김자바", 90);
		map.put("강자바", 80);
		map.put("박자바", 76);
		map.put("김자바", 95);
		map.put("홍자바", 85);
		
		System.out.println(map.size());
		System.out.println("김자바 : "+ map.get("김자바"));
		

	}

}
