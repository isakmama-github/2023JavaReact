package exam12;

public class Dish {
	private boolean empty = true;
	
	public boolean isEmpty() {
		return empty;
	}
	
	public void setEmpty(boolean empty) {
		this.empty = empty;
	}

}
